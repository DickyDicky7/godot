/**
 * bt_condition.h
 * =============================================================================
 * Copyright 2021-2023 Serhii Snitsaruk
 *
 * Use of this source code is governed by an MIT-style
 * license that can be found in the LICENSE file or at
 * https://opensource.org/licenses/MIT.
 * =============================================================================
 */

#ifndef BT_CONDITION_H
#define BT_CONDITION_H

#include "bt_task.h"

class BTCondition : public BTTask {
	GDCLASS(BTCondition, BTTask);

public:
	virtual PackedStringArray get_configuration_warnings() const override;
};

#endif // BT_CONDITION_H